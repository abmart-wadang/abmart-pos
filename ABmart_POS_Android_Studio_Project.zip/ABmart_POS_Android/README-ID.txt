ABmart POS Android — proyek native awal
=======================================

Target perangkat uji: Vivo Y15s, Android 12, RAM 3 GB.
Application ID: id.abmart.pos
Minimum Android: 6.0 (API 23)

CARA MEMBUKA DAN MEMBANGUN APK
1. Di komputer Windows/Mac/Linux, instal Android Studio versi stabil.
2. Ekstrak folder ABmart_POS_Android.
3. Android Studio > Open > pilih folder proyek ABmart_POS_Android.
4. Tunggu Gradle Sync selesai (butuh internet untuk mengunduh dependensi).
5. Hubungkan HP Android dengan USB debugging, atau gunakan emulator.
6. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.
8. Salin APK ke Vivo Y15s dan instal. Untuk distribusi, buat signed release APK melalui Build > Generate Signed Bundle / APK.

FITUR DALAM PROYEK INI
- Aplikasi Android native Kotlin.
- Database lokal SQLite untuk produk, stok, dan transaksi.
- Keranjang, pembayaran, hitung kembalian.
- Ringkasan omzet harian.
- Pemilihan perangkat Bluetooth berpasangan dan perintah cetak ESC/POS dasar.

BELUM SELESAI / WAJIB DIKERJAKAN SEBELUM OPERASIONAL
- Scanner kamera live belum diimplementasikan; dependensi ML Kit sudah disertakan sebagai dasar.
- Sinkronisasi cloud multi-perangkat, login kasir, dan manajemen konflik stok belum diimplementasikan.
- Cetak QPOS harus diuji langsung. Printer bisa memakai Bluetooth Classic/SPP atau protokol lain; perintah ESC/POS hanya contoh dasar.
- Belum diuji build di perangkat nyata. Proyek sumber bukan APK siap instal.

PENTING
Ini adalah proyek native awal yang dapat dibuka dan dilanjutkan di Android Studio,
bukan file APK jadi. Jangan gunakan sebagai sistem kasir produksi sebelum fitur
yang ditandai belum selesai diimplementasikan dan diuji.
