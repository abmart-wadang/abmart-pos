package id.abmart.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Product(val id: Long, val name: String, val barcode: String, val price: Long, val stock: Int)

class Db(context: Context) : SQLiteOpenHelper(context, "abmart.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,barcode TEXT UNIQUE,price INTEGER NOT NULL,stock INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,total INTEGER,paid INTEGER,change_amount INTEGER,items TEXT)")
        val samples = listOf(
            arrayOf("Mi instan","899000000001","3500","24"),
            arrayOf("Air mineral","899000000002","3000","24"),
            arrayOf("Kopi sachet","899000000003","1500","24")
        )
        samples.forEach { a -> db.execSQL("INSERT INTO products(name,barcode,price,stock) VALUES(?,?,?,?)", a) }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun products(query: String = ""): List<Product> {
        val out = mutableListOf<Product>()
        val c = readableDatabase.rawQuery("SELECT id,name,COALESCE(barcode,''),price,stock FROM products WHERE name LIKE ? OR barcode LIKE ? ORDER BY name", arrayOf("%$query%","%$query%"))
        c.use { while(it.moveToNext()) out.add(Product(it.getLong(0),it.getString(1),it.getString(2),it.getLong(3),it.getInt(4))) }
        return out
    }
    fun productByBarcode(code: String): Product? = products(code).firstOrNull { it.barcode == code }
    fun saveProduct(id: Long?, name: String, barcode: String, price: Long, stock: Int) {
        val v=ContentValues().apply { put("name",name); put("barcode",barcode.ifBlank { null }); put("price",price); put("stock",stock) }
        if(id==null) writableDatabase.insert("products",null,v) else writableDatabase.update("products",v,"id=?", arrayOf(id.toString()))
    }
    fun deleteProduct(id: Long) { writableDatabase.delete("products","id=?", arrayOf(id.toString())) }
    fun checkout(items: List<Pair<Product,Int>>, total: Long, paid: Long) {
        val db=writableDatabase
        db.beginTransaction()
        try {
            items.forEach { (p,q) ->
                val c=db.rawQuery("SELECT stock FROM products WHERE id=?", arrayOf(p.id.toString()))
                val stock=c.use { if(it.moveToFirst()) it.getInt(0) else 0 }
                require(stock>=q) { "Stok ${p.name} tidak cukup" }
                db.execSQL("UPDATE products SET stock=stock-? WHERE id=?", arrayOf(q,p.id))
            }
            val desc=items.joinToString("|") { "${it.first.name} x${it.second}" }
            val v=ContentValues().apply { put("created_at",System.currentTimeMillis().toString()); put("total",total); put("paid",paid); put("change_amount",paid-total); put("items",desc) }
            db.insert("sales",null,v); db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun todaySummary(): Pair<Int,Long> {
        val start=java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli().toString()
        val c=readableDatabase.rawQuery("SELECT COUNT(*),COALESCE(SUM(total),0) FROM sales WHERE CAST(created_at AS INTEGER)>=?",arrayOf(start))
        return c.use { if(it.moveToFirst()) Pair(it.getInt(0),it.getLong(1)) else Pair(0,0L) }
    }
}
