package id.abmart.pos

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.io.OutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var db: Db
    private lateinit var body: LinearLayout
    private val cart = linkedMapOf<Long, Pair<Product,Int>>()
    private var printerSocket: BluetoothSocket? = null
    private val btUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if(it) scanBarcode() else toast("Izin kamera diperlukan") }
    private val btPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if(it) choosePrinter() else toast("Izin Bluetooth diperlukan") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=Db(this)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(0xFFF3F7FB.toInt()) }
        val header=TextView(this).apply { text="ABmart POS"; textSize=23f; setTextColor(-1); setPadding(18,18,18,18); setBackgroundColor(0xFF168BD2.toInt()); setTypeface(null,1) }
        root.addView(header)
        val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(6,6,6,6) }
        listOf("Kasir","Produk","Laporan","Printer").forEach { label -> tabs.addView(Button(this).apply { text=label; setOnClickListener { when(label) { "Kasir"->showCashier(); "Produk"->showProducts(); "Laporan"->showReports(); else->printerPage() } } },LinearLayout.LayoutParams(0,-2,1f)) }
        root.addView(tabs)
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,8,14,12) }
        val scroll=ScrollView(this); scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); showCashier()
    }
    private fun label(s:String,size:Float=16f)=TextView(this).apply { text=s; textSize=size; setTextColor(0xFF183246.toInt()); setPadding(4,9,4,9) }
    private fun field(hint:String)=EditText(this).apply { this.hint=hint; textSize=15f; setSingleLine(true); setPadding(12,10,12,10) }
    private fun btn(s:String, action:()->Unit)=Button(this).apply { text=s; setOnClickListener { action() } }
    private fun money(n:Long)="Rp"+String.format("%,d",n).replace(',','.')
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun showCashier() {
        body.removeAllViews(); val search=field("Cari nama / barcode"); body.addView(search)
        val scan=btn("📷 Scan barcode kamera") { if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) scanBarcode() else cameraPermission.launch(Manifest.permission.CAMERA) }; body.addView(scan)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; body.addView(list)
        val totalView=label("",21f); body.addView(label("Keranjang",18f)); val cartView=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; body.addView(cartView)
        val paid=field("Uang diterima (Rp)"); paid.inputType=2; body.addView(totalView); body.addView(paid)
        val refresh:()->Unit = {
            list.removeAllViews()
            db.products(search.text.toString()).forEach { p -> list.addView(btn("${p.name} • ${money(p.price)} • Stok ${p.stock}") {
                val old=cart[p.id]; cart[p.id]=Pair(p,(old?.second?:0)+1); renderCart(cartView,totalView)
            }) }
        }
        search.addTextChangedListener(SimpleWatcher { refresh() })
        refresh(); renderCart(cartView,totalView)
        body.addView(btn("BAYAR & SIMPAN") {
            val total=cart.values.sumOf { it.first.price*it.second }; val pay=paid.text.toString().toLongOrNull()?:0L
            if(cart.isEmpty()) toast("Keranjang kosong") else if(pay<total) toast("Uang diterima kurang") else try {
                db.checkout(cart.values.toList(),total,pay); cart.clear(); paid.setText(""); renderCart(cartView,totalView); refresh(); toast("Transaksi tersimpan. Kembalian ${money(pay-total)}")
            } catch(e:Exception) { toast(e.message ?: "Gagal menyimpan") }
        })
    }
    private fun renderCart(view:LinearLayout,totalView:TextView) {
        view.removeAllViews(); cart.values.forEach { (p,q)->view.addView(label("${p.name}  x$q  = ${money(p.price*q)}")) }
        totalView.text="TOTAL: "+money(cart.values.sumOf { it.first.price*it.second })
    }
    private fun showProducts() {
        body.removeAllViews(); body.addView(label("Tambah produk",19f))
        val name=field("Nama barang"); val barcode=field("Barcode (opsional)"); val price=field("Harga jual"); price.inputType=2; val stock=field("Stok"); stock.inputType=2
        listOf(name,barcode,price,stock).forEach { body.addView(it) }
        body.addView(btn("Simpan produk") { val n=name.text.toString().trim(); val p=price.text.toString().toLongOrNull(); val s=stock.text.toString().toIntOrNull(); if(n.isBlank()||p==null||s==null)toast("Lengkapi data produk") else try { db.saveProduct(null,n,barcode.text.toString(),p,s); toast("Produk tersimpan"); showProducts() } catch(e:Exception){toast("Barcode sudah digunakan")} })
        body.addView(label("Daftar produk",18f))
        db.products().forEach { p -> body.addView(label("${p.name} • ${p.barcode} • ${money(p.price)} • Stok ${p.stock}")); body.addView(btn("Hapus ${p.name}") { db.deleteProduct(p.id); showProducts() }) }
    }
    private fun showReports() {
        body.removeAllViews(); val s=db.todaySummary(); body.addView(label("Laporan hari ini",20f)); body.addView(label("Jumlah transaksi: ${s.first}",18f)); body.addView(label("Omzet: ${money(s.second)}",22f))
    }
    private fun printerPage() {
        body.removeAllViews(); body.addView(label("Printer Bluetooth QPOS",20f))
        body.addView(label("Pilih printer Bluetooth yang sudah dipasangkan melalui Pengaturan Bluetooth Android."))
        body.addView(btn("Hubungkan printer") { if(Build.VERSION.SDK_INT>=31 && ContextCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) btPermission.launch(Manifest.permission.BLUETOOTH_CONNECT) else choosePrinter() })
        body.addView(btn("Cetak tes") { testPrint() })
        body.addView(label("Catatan: cetak membutuhkan printer Bluetooth Classic/SPP dan kompatibilitas ESC/POS. Model printer perlu diuji langsung."))
    }
    private fun choosePrinter() {
        try {
            val adapter=BluetoothAdapter.getDefaultAdapter() ?: throw Exception("Bluetooth tidak tersedia")
            val paired=adapter.bondedDevices.toList()
            if(paired.isEmpty()) { toast("Pairing QPOS dahulu di Pengaturan Bluetooth"); return }
            val names=paired.map { "${it.name} (${it.address})" }.toTypedArray()
            android.app.AlertDialog.Builder(this).setTitle("Pilih printer QPOS").setItems(names) { _,which ->
                Thread {
                    try { val device=paired[which]; val socket=device.createRfcommSocketToServiceRecord(btUuid); adapter.cancelDiscovery(); socket.connect(); printerSocket=socket; runOnUiThread { toast("Terhubung ke ${device.name}") } }
                    catch(e:Exception) { runOnUiThread { toast("Gagal terhubung: ${e.message}") } }
                }.start()
            }.show()
        } catch(e:SecurityException) { toast("Izin Bluetooth belum diberikan") } catch(e:Exception) { toast(e.message ?: "Bluetooth gagal") }
    }
    private fun testPrint() {
        Thread { try { val out:OutputStream=printerSocket?.outputStream ?: throw Exception("Hubungkan printer dahulu")
            out.write(byteArrayOf(0x1B,0x40)); out.write("ABMART\nTES PRINTER\nBluetooth QPOS\n\n\n".toByteArray(Charsets.UTF_8)); out.write(byteArrayOf(0x1D,0x56,0x00)); out.flush()
            runOnUiThread { toast("Perintah cetak tes dikirim") }
        } catch(e:Exception) { runOnUiThread { toast(e.message ?: "Cetak gagal") } } }.start()
    }
    private fun scanBarcode() {
        // Pemindai berbasis ML Kit: mengambil gambar melalui intent kamera sederhana tidak
        // disediakan pada scaffold ini; integrasi CameraX diperlukan untuk pemindaian live.
        toast("Modul ML Kit sudah disiapkan. Pemindaian live CameraX perlu tahap integrasi berikutnya.")
    }
}
